public class ProxyPatternExample {

    // Subject Interface
    interface Image {
        void display();
    }

    // Real Subject
    static class RealImage implements Image {
        private String fileName;

        RealImage(String fileName) {
            this.fileName = fileName;
            loadImageFromServer();
        }

        private void loadImageFromServer() {
            System.out.println("Loading image: " + fileName);
        }

        @Override
        public void display() {
            System.out.println("Displaying image: " + fileName);
        }
    }

    // Proxy Class
    static class ProxyImage implements Image {
        private RealImage realImage;
        private String fileName;

        ProxyImage(String fileName) {
            this.fileName = fileName;
        }

        @Override
        public void display() {
            if (realImage == null) {
                realImage = new RealImage(fileName);
            }
            realImage.display();
        }
    }

    // Test Class
    public static void main(String[] args) {
        Image image1 = new ProxyImage("photo1.jpg");
        Image image2 = new ProxyImage("photo2.jpg");

        System.out.println("First call to display image1:");
        image1.display(); // Loads and displays the image

        System.out.println("\nSecond call to display image1:");
        image1.display(); // Displays the image without reloading

        System.out.println("\nCall to display image2:");
        image2.display(); // Loads and displays the image
    }
}

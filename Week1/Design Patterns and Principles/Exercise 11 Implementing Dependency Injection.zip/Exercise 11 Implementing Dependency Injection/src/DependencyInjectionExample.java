public class DependencyInjectionExample {

    // Repository Interface
    interface CustomerRepository {
        String findCustomerById(int id);
    }

    // Concrete Repository Implementation
    static class CustomerRepositoryImpl implements CustomerRepository {
        @Override
        public String findCustomerById(int id) {
            // Simulate finding a customer by ID
            return "Customer with ID: " + id;
        }
    }

    // Service Class
    static class CustomerService {
        private CustomerRepository customerRepository;

        // Constructor Injection
        public CustomerService(CustomerRepository customerRepository) {
            this.customerRepository = customerRepository;
        }

        public String getCustomerInfo(int id) {
            return customerRepository.findCustomerById(id);
        }
    }

    // Test Class
    public static void main(String[] args) {
        // Create an instance of CustomerRepositoryImpl
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        // Inject CustomerRepository into CustomerService
        CustomerService customerService = new CustomerService(customerRepository);

        // Use CustomerService to find and display customer information
        int customerId = 1;
        String customerInfo = customerService.getCustomerInfo(customerId);
        System.out.println(customerInfo);
    }
}

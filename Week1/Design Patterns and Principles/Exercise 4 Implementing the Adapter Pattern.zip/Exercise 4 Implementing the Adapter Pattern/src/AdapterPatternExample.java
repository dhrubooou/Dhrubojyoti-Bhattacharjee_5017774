public class AdapterPatternExample {

    // Target Interface
    interface PaymentProcessor {
        void processPayment(double amount);
    }

    // Adaptee Classes
    static class PayPalPayment {
        void makePayment(double amount) {
            System.out.println("Processing payment through PayPal: $" + amount);
        }
    }

    static class StripePayment {
        void process(double amount) {
            System.out.println("Processing payment through Stripe: $" + amount);
        }
    }

    // Adapter Classes
    static class PayPalAdapter implements PaymentProcessor {
        private PayPalPayment payPalPayment;

        PayPalAdapter(PayPalPayment payPalPayment) {
            this.payPalPayment = payPalPayment;
        }

        @Override
        public void processPayment(double amount) {
            payPalPayment.makePayment(amount);
        }
    }

    static class StripeAdapter implements PaymentProcessor {
        private StripePayment stripePayment;

        StripeAdapter(StripePayment stripePayment) {
            this.stripePayment = stripePayment;
        }

        @Override
        public void processPayment(double amount) {
            stripePayment.process(amount);
        }
    }

    // Test Class
    public static void main(String[] args) {
        PaymentProcessor paypalProcessor = new PayPalAdapter(new PayPalPayment());
        PaymentProcessor stripeProcessor = new StripeAdapter(new StripePayment());

        System.out.println("Testing PayPal Adapter:");
        paypalProcessor.processPayment(100.00);

        System.out.println("\nTesting Stripe Adapter:");
        stripeProcessor.processPayment(200.00);
    }
}

public class CommandPatternExample {

    // Command Interface
    interface Command {
        void execute();
    }

    // Receiver Class
    static class Light {
        void turnOn() {
            System.out.println("The light is on.");
        }

        void turnOff() {
            System.out.println("The light is off.");
        }
    }

    // Concrete Command - LightOnCommand
    static class LightOnCommand implements Command {
        private Light light;

        LightOnCommand(Light light) {
            this.light = light;
        }

        @Override
        public void execute() {
            light.turnOn();
        }
    }

    // Concrete Command - LightOffCommand
    static class LightOffCommand implements Command {
        private Light light;

        LightOffCommand(Light light) {
            this.light = light;
        }

        @Override
        public void execute() {
            light.turnOff();
        }
    }

    // Invoker Class
    static class RemoteControl {
        private Command command;

        void setCommand(Command command) {
            this.command = command;
        }

        void pressButton() {
            command.execute();
        }
    }

    // Test Class
    public static void main(String[] args) {
        Light livingRoomLight = new Light();

        Command lightOn = new LightOnCommand(livingRoomLight);
        Command lightOff = new LightOffCommand(livingRoomLight);

        RemoteControl remote = new RemoteControl();

        System.out.println("Turning the light on:");
        remote.setCommand(lightOn);
        remote.pressButton();

        System.out.println("\nTurning the light off:");
        remote.setCommand(lightOff);
        remote.pressButton();
    }
}

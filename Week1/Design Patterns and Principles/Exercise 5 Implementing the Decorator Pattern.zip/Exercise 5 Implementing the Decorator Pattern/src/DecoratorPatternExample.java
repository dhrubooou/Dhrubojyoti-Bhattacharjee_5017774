public class DecoratorPatternExample {

    // Component Interface
    interface Notifier {
        void send(String message);
    }

    // Concrete Component
    static class EmailNotifier implements Notifier {
        @Override
        public void send(String message) {
            System.out.println("Sending Email: " + message);
        }
    }

    // Abstract Decorator
    static abstract class NotifierDecorator implements Notifier {
        protected Notifier decoratedNotifier;

        NotifierDecorator(Notifier notifier) {
            this.decoratedNotifier = notifier;
        }

        @Override
        public void send(String message) {
            decoratedNotifier.send(message);
        }
    }

    // Concrete Decorator for SMS
    static class SMSNotifierDecorator extends NotifierDecorator {
        SMSNotifierDecorator(Notifier notifier) {
            super(notifier);
        }

        @Override
        public void send(String message) {
            super.send(message); // Call the method in the original notifier
            System.out.println("Sending SMS: " + message);
        }
    }

    // Concrete Decorator for Slack
    static class SlackNotifierDecorator extends NotifierDecorator {
        SlackNotifierDecorator(Notifier notifier) {
            super(notifier);
        }

        @Override
        public void send(String message) {
            super.send(message); // Call the method in the original notifier
            System.out.println("Sending Slack message: " + message);
        }
    }

    // Test Class
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();

        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);

        System.out.println("Sending notifications with decorators:");
        slackNotifier.send("Hello, this is a test message.");
    }
}

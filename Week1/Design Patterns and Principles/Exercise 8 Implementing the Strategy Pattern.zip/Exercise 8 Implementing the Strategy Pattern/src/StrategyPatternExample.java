public class StrategyPatternExample {

    // Strategy Interface
    interface PaymentStrategy {
        void pay(double amount);
    }

    // Concrete Strategy - CreditCardPayment
    static class CreditCardPayment implements PaymentStrategy {
        private String cardNumber;

        CreditCardPayment(String cardNumber) {
            this.cardNumber = cardNumber;
        }

        @Override
        public void pay(double amount) {
            System.out.println("Paying $" + amount + " using Credit Card: " + cardNumber);
        }
    }

    // Concrete Strategy - PayPalPayment
    static class PayPalPayment implements PaymentStrategy {
        private String email;

        PayPalPayment(String email) {
            this.email = email;
        }

        @Override
        public void pay(double amount) {
            System.out.println("Paying $" + amount + " using PayPal with email: " + email);
        }
    }

    // Context Class
    static class PaymentContext {
        private PaymentStrategy paymentStrategy;

        PaymentContext(PaymentStrategy paymentStrategy) {
            this.paymentStrategy = paymentStrategy;
        }

        void executePayment(double amount) {
            paymentStrategy.pay(amount);
        }
    }

    // Test Class
    public static void main(String[] args) {
        // Using CreditCardPayment
        PaymentStrategy creditCard = new CreditCardPayment("1234-5678-9876-5432");
        PaymentContext context = new PaymentContext(creditCard);
        System.out.println("Testing Credit Card Payment:");
        context.executePayment(100.00);

        // Using PayPalPayment
        PaymentStrategy payPal = new PayPalPayment("user@example.com");
        context = new PaymentContext(payPal);
        System.out.println("\nTesting PayPal Payment:");
        context.executePayment(200.00);
    }
}

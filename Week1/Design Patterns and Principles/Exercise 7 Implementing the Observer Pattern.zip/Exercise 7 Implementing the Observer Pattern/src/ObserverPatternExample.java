import java.util.ArrayList;
import java.util.List;

// Main class for the Observer Pattern example
public class ObserverPatternExample {

    // Subject Interface
    interface Stock {
        void registerObserver(Observer observer);
        void deregisterObserver(Observer observer);
        void notifyObservers();
    }

    // Concrete Subject
    static class StockMarket implements Stock {
        private List<Observer> observers = new ArrayList<>();
        private String stockName;
        private double stockPrice;

        StockMarket(String stockName) {
            this.stockName = stockName;
        }

        void setStockPrice(double price) {
            this.stockPrice = price;
            notifyObservers();
        }

        @Override
        public void registerObserver(Observer observer) {
            observers.add(observer);
        }

        @Override
        public void deregisterObserver(Observer observer) {
            observers.remove(observer);
        }

        @Override
        public void notifyObservers() {
            for (Observer observer : observers) {
                observer.update(stockName, stockPrice);
            }
        }
    }

    // Observer Interface
    interface Observer {
        void update(String stockName, double stockPrice);
    }

    // Concrete Observer - MobileApp
    static class MobileApp implements Observer {
        @Override
        public void update(String stockName, double stockPrice) {
            System.out.println("Mobile App - Stock: " + stockName + ", Price: $" + stockPrice);
        }
    }

    // Concrete Observer - WebApp
    static class WebApp implements Observer {
        @Override
        public void update(String stockName, double stockPrice) {
            System.out.println("Web App - Stock: " + stockName + ", Price: $" + stockPrice);
        }
    }

    // Test Class
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket("TechCorp");

        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        System.out.println("Updating stock price to $150:");
        stockMarket.setStockPrice(150.00);

        System.out.println("\nDeregistering MobileApp and updating stock price to $175:");
        stockMarket.deregisterObserver(mobileApp);
        stockMarket.setStockPrice(175.00);
    }
}

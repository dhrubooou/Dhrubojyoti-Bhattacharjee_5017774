import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LibraryManagementSystem {

    // Class representing a Book
    public static class Book {
        private int bookId;
        private String title;
        private String author;

        public Book(int bookId, String title, String author) {
            this.bookId = bookId;
            this.title = title;
            this.author = author;
        }

        public int getBookId() {
            return bookId;
        }

        public String getTitle() {
            return title;
        }

        public String getAuthor() {
            return author;
        }

        @Override
        public String toString() {
            return "Book{" +
                    "bookId=" + bookId +
                    ", title='" + title + '\'' +
                    ", author='" + author + '\'' +
                    '}';
        }
    }

    // Method for linear search by title
    public static Book linearSearchByTitle(List<Book> books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null; // Book not found
    }

    // Method for binary search by title
    public static Book binarySearchByTitle(List<Book> books, String title) {
        int low = 0;
        int high = books.size() - 1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            Book midBook = books.get(mid);
            int comparison = midBook.getTitle().compareToIgnoreCase(title);
            if (comparison == 0) {
                return midBook;
            } else if (comparison < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null; // Book not found
    }

    // Main method to demonstrate the usage
    public static void main(String[] args) {
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "Java Programming", "John Doe"));
        books.add(new Book(2, "Data Structures", "Jane Smith"));
        books.add(new Book(3, "Algorithms", "John Doe"));

        // Sort books by title for binary search
        Collections.sort(books, (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));

        // Linear Search
        Book foundBookLinear = linearSearchByTitle(books, "Java Programming");
        System.out.println("Linear Search Result: " + foundBookLinear);

        // Binary Search
        Book foundBookBinary = binarySearchByTitle(books, "Data Structures");
        System.out.println("Binary Search Result: " + foundBookBinary);
    }
}

package Ex7.src;

import java.util.HashMap;
import java.util.Map;

public class FinancialForecasting {

    // A map to store the results of calculated future values to avoid redundant calculations
    private static Map<Integer, Double> memo = new HashMap<>();

    /**
     * Calculate the future value using recursion with memoization.
     *
     * @param initialValue The starting value.
     * @param growthRate The growth rate per period (e.g., 0.05 for 5%).
     * @param periods The number of periods to forecast.
     * @return The predicted future value.
     */
    public static double calculateFutureValue(double initialValue, double growthRate, int periods) {
        // Check if the result is already computed and stored in memo.
        if (memo.containsKey(periods)) {
            return memo.get(periods);
        }
        // Base Case: If no periods are left, return the initial value.
        if (periods == 0) {
            return initialValue;
        }
        // Recursive Case: Calculate the future value for one period less and apply growth rate.
        double futureValue = calculateFutureValue(initialValue, growthRate, periods - 1) * (1 + growthRate);
        // Store the result in memo.
        memo.put(periods, futureValue);
        return futureValue;
    }

    public static void main(String[] args) {
        double initialValue = 1000.0; // Example initial value
        double growthRate = 0.05; // 5% growth rate
        int periods = 10; // Forecast for 10 periods

        double futureValue = calculateFutureValue(initialValue, growthRate, periods);
        System.out.println("Future Value: " + futureValue);
    }
}

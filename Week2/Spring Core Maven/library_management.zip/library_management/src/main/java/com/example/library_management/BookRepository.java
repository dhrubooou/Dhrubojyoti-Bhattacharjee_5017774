package main.java.com.example.library_management;

public class BookRepository {
    public void performRepositoryOperation() {
        System.out.println("Performing repository operation in BookRepository");
    }
}

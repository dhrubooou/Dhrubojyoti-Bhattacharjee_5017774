package com.example.librarymanagement;

public @interface SpringBootTest {

}

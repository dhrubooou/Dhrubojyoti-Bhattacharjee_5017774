package com.library.repository;

public class BookRepository {
    public void performRepositoryOperation() {
        System.out.println("Performing operation in BookRepository");
        // Simulate some work with sleep
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

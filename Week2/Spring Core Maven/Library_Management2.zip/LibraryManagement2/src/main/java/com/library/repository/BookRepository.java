package com.library.repository;

import java.util.Arrays;
import java.util.List;

public class BookRepository {

    // Sample method to get a list of books
    public List<String> getBooks() {
        return Arrays.asList("Book1", "Book2", "Book3");
    }
}


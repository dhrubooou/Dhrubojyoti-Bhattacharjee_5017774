package com.employee.repository;

import java.util.List;
import com.employee.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Find employees by name
    List<Employee> findByName(String name);

    // Find employees by department name
    List<Employee> findByDepartmentName(String departmentName);

    // Find employees with email containing a certain substring
    List<Employee> findByEmailContaining(String emailSubstring);
}

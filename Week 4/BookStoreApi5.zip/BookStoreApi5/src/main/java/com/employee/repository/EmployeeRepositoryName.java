package com.employee.repository;

import java.util.List;
import com.employee.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import jakarta.persistence.NamedQuery;

@SuppressWarnings("unused")
@Repository
public interface EmployeeRepositoryName extends JpaRepository<Employee, Long> {

    @Query(name = "Employee.findByName")
    List<Employee> findByName(String name);

    @Query(name = "Employee.findByDepartmentName")
    List<Employee> findByDepartmentName(String departmentName);
}
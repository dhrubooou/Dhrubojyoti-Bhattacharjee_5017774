package com.employee.repository;

import com.employee.entity.Employee;
import com.employee.dto.EmployeeDTO;
import com.employee.projection.EmployeeProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query("SELECT e.id as id, e.name as name, e.email as email, d.name as departmentName " +
           "FROM Employee e JOIN e.department d")
    List<EmployeeProjection> findAllEmployeeProjections();
    
    @Query("SELECT new com.employee.dto.EmployeeDTO(e.id, e.name, e.email, d.name) " +
            "FROM Employee e JOIN e.department d")
     List<EmployeeDTO> findAllEmployeeDTOs();
}




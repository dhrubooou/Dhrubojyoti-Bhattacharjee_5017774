package com.employee.projection;

public interface EmployeeProjection {
    Long getId();
    String getName();
    String getEmail();
    String getDepartmentName(); // For joining with Department entity
}


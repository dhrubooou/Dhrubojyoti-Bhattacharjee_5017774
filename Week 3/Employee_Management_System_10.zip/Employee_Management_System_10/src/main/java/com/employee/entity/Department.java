package com.employee.entity;

import jakarta.persistence.*;
import java.util.List;
import org.hibernate.annotations.BatchSize;

@Entity
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @OneToMany(mappedBy = "department")
    @BatchSize(size = 10)
    private List<Employee> employees;

    // getters and setters
}